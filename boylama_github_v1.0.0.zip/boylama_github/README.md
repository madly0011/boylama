# Boylama — Android/iOS Uygulaması

Meyve kasası boyut tespiti. Kameradan canlı video veya fotoğraf ile kasanın kaç'lık olduğunu tespit eder.

## Kurulum

### Gereksinimler
- Flutter SDK 3.0+
- Android Studio veya VS Code
- Android 6.0+ cihaz veya emülatör

### Adımlar

```bash
# 1. Bağımlılıkları yükle
flutter pub get

# 2. Android için çalıştır
flutter run

# 3. APK oluştur
flutter build apk --release
```

APK konumu: `build/app/outputs/flutter-apk/app-release.apk`

## Klasör Yapısı

```
lib/
├── main.dart              ← Giriş noktası
├── kasa_analiz.dart       ← Analiz motoru (KNN + köşe tespiti)
├── screens/
│   └── kamera_ekrani.dart ← Ana kamera ekranı
└── widgets/
    ├── sonuc_karti.dart   ← Sonuç gösterimi
    └── canli_overlay.dart ← Canlı mod overlay

assets/
├── kasa_veri.json         ← Kasa şemaları + öğrenilen veriler
└── kasa_model.tflite      ← (İleride) TFLite modeli
```

## Kullanım

### Fotoğraf modu
1. Kasayı çerçevele
2. Beyaz butona bas
3. Sonuç kartında kasa boyutu görünür

### Canlı mod
1. Sağ üstten "Canlı: KAPALI" a bas → "Canlı: AÇIK" olur
2. Kamerayı kasaya tut — her 1.5 saniyede analiz yapar
3. Ekranda kasa boyutu sürekli güncellenir

### Yeni kasa öğretme
- Sistem tanımadığı bir kasa gördüğünde dialog açar
- Kaç'lık olduğunu yaz → "Öğret" e bas
- Bir sonraki analizde tanır

## TFLite Entegrasyonu (İleride)

Yeterli fotoğraf biriktikten sonra:

```bash
# Python tarafında TFLite modeli oluştur
python boylama.py --egit-tflite

# Oluşan modeli assets'e kopyala
cp kasa_model.tflite boylama_app/assets/
```

`kasa_analiz.dart` içindeki `KasaAnalizMotoru.analiz()` metodu
otomatik olarak TFLite modeline geçer.
