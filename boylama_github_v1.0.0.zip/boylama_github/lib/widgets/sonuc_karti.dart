// Version: 1.0.0
import 'package:flutter/material.dart';
import '../kasa_analiz.dart';

class SonucKarti extends StatelessWidget {
  final AnalizSonucu sonuc;
  const SonucKarti({super.key, required this.sonuc});

  Color get _renkGuven {
    if (sonuc.bilinmiyor) return Colors.orange;
    if (sonuc.guven >= 0.85) return Colors.green;
    if (sonuc.guven >= 0.70) return Colors.yellow;
    return Colors.orange;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.85),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _renkGuven.withOpacity(0.6), width: 1.5),
      ),
      child: Row(
        children: [
          // Kasa ikonu + boyut
          Container(
            width: 60, height: 60,
            decoration: BoxDecoration(
              color: _renkGuven.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _renkGuven, width: 1.5),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  sonuc.bilinmiyor ? Icons.help : Icons.inventory_2,
                  color: _renkGuven, size: 22,
                ),
                Text(
                  sonuc.bilinmiyor ? '?' : "${sonuc.kasaBoyutu}'",
                  style: TextStyle(
                    color: _renkGuven,
                    fontWeight: FontWeight.bold,
                    fontSize: sonuc.bilinmiyor ? 20 : 14,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 14),

          // Detaylar
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  sonuc.bilinmiyor
                      ? 'Kasa Tanınamadı'
                      : "${sonuc.kasaBoyutu}'lik Kasa",
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 4),
                Row(children: [
                  _bilgiChip(Icons.circle, '${sonuc.toplamMeyve} meyve', Colors.blue),
                  const SizedBox(width: 6),
                  _bilgiChip(Icons.grid_view, sonuc.patternStr, Colors.purple),
                ]),
                const SizedBox(height: 4),
                // Güven çubuğu
                Row(children: [
                  const Text('Güven: ', style: TextStyle(color: Colors.grey, fontSize: 11)),
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: sonuc.guven,
                        backgroundColor: Colors.grey[800],
                        valueColor: AlwaysStoppedAnimation(_renkGuven),
                        minHeight: 6,
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(sonuc.guvenStr,
                    style: TextStyle(color: _renkGuven, fontSize: 11)),
                ]),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _bilgiChip(IconData icon, String text, Color renk) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: renk.withOpacity(0.15),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(children: [
        Icon(icon, size: 10, color: renk),
        const SizedBox(width: 3),
        Text(text, style: TextStyle(color: renk, fontSize: 11)),
      ]),
    );
  }
}
