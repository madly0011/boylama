// Version: 1.0.0
import 'package:flutter/material.dart';
import '../kasa_analiz.dart';

class CanliOverlay extends StatelessWidget {
  final AnalizSonucu sonuc;
  const CanliOverlay({super.key, required this.sonuc});

  @override
  Widget build(BuildContext context) {
    if (sonuc.bilinmiyor || sonuc.kasaBoyutu == null) return const SizedBox();

    return Positioned(
      top: 100,
      left: 0, right: 0,
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.green.withOpacity(0.85),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(
            "${sonuc.kasaBoyutu}'lik  •  ${sonuc.toplamMeyve} meyve  •  ${sonuc.guvenStr}",
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}
