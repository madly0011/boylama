// Version: 1.0.0
// Boylama — Meyve Kasası Tespit Uygulaması
// Flutter + TFLite + Offline

import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'screens/kamera_ekrani.dart';

List<CameraDescription> cameras = [];

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  cameras = await availableCameras();
  runApp(const BoylamaApp());
}

class BoylamaApp extends StatelessWidget {
  const BoylamaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Boylama',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2E7D32),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: KameraEkrani(cameras: cameras),
    );
  }
}
