// Version: 1.0.0
// Ana Kamera Ekranı — Canlı video + buton ile analiz

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:camera/camera.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:image/image.dart' as img;
import '../kasa_analiz.dart';
import '../widgets/sonuc_karti.dart';
import '../widgets/canli_overlay.dart';

class KameraEkrani extends StatefulWidget {
  final List<CameraDescription> cameras;
  const KameraEkrani({super.key, required this.cameras});

  @override
  State<KameraEkrani> createState() => _KameraEkraniState();
}

class _KameraEkraniState extends State<KameraEkrani>
    with WidgetsBindingObserver {

  CameraController? _controller;
  bool _hazir = false;
  bool _analizEdiliyor = false;
  bool _canliMod = false;         // Canlı sürekli analiz
  AnalizSonucu? _sonSonuc;
  final KasaAnalizMotoru _motor = KasaAnalizMotoru();
  Timer? _canliTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _veriYukle().then((_) => _kameraBaslat());
  }

  Future<void> _veriYukle() async {
    try {
      final json = await rootBundle.loadString('assets/kasa_veri.json');
      final veri = jsonDecode(json) as Map<String, dynamic>;
      _motor.baslat(veri);
    } catch (_) {
      // Varsayılan şemalarla devam et
      _motor.baslat({});
    }
  }

  Future<void> _kameraBaslat() async {
    if (widget.cameras.isEmpty) return;
    _controller = CameraController(
      widget.cameras[0],
      ResolutionPreset.high,
      enableAudio: false,
      imageFormatGroup: ImageFormatGroup.jpeg,
    );
    await _controller!.initialize();
    if (mounted) setState(() => _hazir = true);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _canliTimer?.cancel();
    _controller?.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (_controller == null || !_controller!.value.isInitialized) return;
    if (state == AppLifecycleState.inactive) {
      _controller?.dispose();
    } else if (state == AppLifecycleState.resumed) {
      _kameraBaslat();
    }
  }

  // ── Tek fotoğraf analizi ────────────────────────────────
  Future<void> _fotografCekAnaliz() async {
    if (_analizEdiliyor || !_hazir) return;
    setState(() => _analizEdiliyor = true);

    try {
      final dosya = await _controller!.takePicture();
      final bytes = await File(dosya.path).readAsBytes();
      final goruntu = img.decodeImage(bytes);
      if (goruntu == null) return;

      final sonuc = _motor.analiz(goruntu);

      if (mounted) {
        setState(() => _sonSonuc = sonuc);
        if (sonuc.bilinmiyor) {
          _kasaOgrenDialog(sonuc, goruntu);
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Hata: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _analizEdiliyor = false);
    }
  }

  // ── Canlı mod ───────────────────────────────────────────
  void _canliModToggle() {
    setState(() => _canliMod = !_canliMod);
    if (_canliMod) {
      _canliTimer = Timer.periodic(
        const Duration(milliseconds: 1500),
        (_) => _canliAnaliz(),
      );
    } else {
      _canliTimer?.cancel();
      setState(() => _sonSonuc = null);
    }
  }

  Future<void> _canliAnaliz() async {
    if (_analizEdiliyor || !_hazir || !mounted) return;
    _analizEdiliyor = true;
    try {
      final dosya  = await _controller!.takePicture();
      final bytes  = await File(dosya.path).readAsBytes();
      final goruntu = img.decodeImage(bytes);
      if (goruntu == null) return;
      final sonuc = _motor.analiz(goruntu);
      if (mounted) setState(() => _sonSonuc = sonuc);
    } catch (_) {
    } finally {
      _analizEdiliyor = false;
    }
  }

  // ── Bilinmeyen kasa dialog ──────────────────────────────
  void _kasaOgrenDialog(AnalizSonucu sonuc, img.Image goruntu) {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1E1E1E),
        title: const Row(children: [
          Icon(Icons.help_outline, color: Colors.orange),
          SizedBox(width: 8),
          Text('Kasa Tanınamadı', style: TextStyle(color: Colors.white)),
        ]),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Tespit: ${sonuc.toplamMeyve} meyve\n'
              'Dizilim: ${sonuc.patternStr}',
              style: const TextStyle(color: Colors.white70),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: ctrl,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'Kaç\'lık kasa?',
                labelStyle: TextStyle(color: Colors.grey),
                hintText: 'Örn: 30',
                hintStyle: TextStyle(color: Colors.grey),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFF2E7D32)),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Atla', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF2E7D32),
            ),
            onPressed: () {
              final kasaNo = int.tryParse(ctrl.text);
              if (kasaNo != null) {
                final fv = featureVektorOlustur(
                  [], [], false,
                  goruntu.height, goruntu.width,
                );
                _motor.yeniKasaOgren(kasaNo, sonuc.siraPattern, fv);
                _veriKaydet();
                setState(() {
                  _sonSonuc = AnalizSonucu(
                    toplamMeyve: sonuc.toplamMeyve,
                    siraPattern: sonuc.siraPattern,
                    siraSayisi: sonuc.siraSayisi,
                    offsetVar: sonuc.offsetVar,
                    kasaBoyutu: kasaNo,
                    guven: 1.0,
                  );
                });
              }
              Navigator.pop(ctx);
            },
            child: const Text('Öğret', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Future<void> _veriKaydet() async {
    try {
      final dir  = await getApplicationDocumentsDirectory();
      final file = File(p.join(dir.path, 'kasa_veri.json'));
      // Basit kayıt — gerçek uygulamada tam veri kaydedilir
      await file.writeAsString('{"saved": true}');
    } catch (_) {}
  }

  // ── UI ─────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Kamera önizleme
          if (_hazir && _controller != null)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _controller!.value.previewSize!.height,
                  height: _controller!.value.previewSize!.width,
                  child: CameraPreview(_controller!),
                ),
              ),
            )
          else
            const Center(child: CircularProgressIndicator(color: Colors.green)),

          // Canlı overlay — sonuç varsa göster
          if (_sonSonuc != null)
            CanliOverlay(sonuc: _sonSonuc!),

          // Üst bar
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Logo
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Row(children: [
                      Icon(Icons.inventory_2, color: Colors.green, size: 18),
                      SizedBox(width: 6),
                      Text('Boylama', style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16,
                      )),
                    ]),
                  ),
                  // Canlı mod toggle
                  GestureDetector(
                    onTap: _canliModToggle,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: _canliMod ? Colors.green : Colors.black54,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: _canliMod ? Colors.greenAccent : Colors.white30,
                        ),
                      ),
                      child: Row(children: [
                        Icon(
                          _canliMod ? Icons.videocam : Icons.videocam_off,
                          color: Colors.white, size: 16,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          _canliMod ? 'Canlı: AÇIK' : 'Canlı: KAPALI',
                          style: const TextStyle(color: Colors.white, fontSize: 12),
                        ),
                      ]),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Alt kontroller
          Positioned(
            bottom: 0,
            left: 0, right: 0,
            child: Container(
              padding: const EdgeInsets.only(bottom: 32, top: 16),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [Colors.black, Colors.transparent],
                ),
              ),
              child: Column(
                children: [
                  // Sonuç kartı
                  if (_sonSonuc != null)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: SonucKarti(sonuc: _sonSonuc!),
                    ),
                  const SizedBox(height: 16),

                  // Çekim butonu
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Sonucu temizle
                      if (_sonSonuc != null)
                        Padding(
                          padding: const EdgeInsets.only(right: 24),
                          child: IconButton(
                            onPressed: () => setState(() => _sonSonuc = null),
                            icon: const Icon(Icons.close, color: Colors.white70),
                            iconSize: 32,
                          ),
                        ),

                      // Ana çekim butonu
                      GestureDetector(
                        onTap: _fotografCekAnaliz,
                        child: Container(
                          width: 72, height: 72,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _analizEdiliyor
                                ? Colors.grey
                                : Colors.white,
                            border: Border.all(
                              color: Colors.green, width: 3,
                            ),
                          ),
                          child: _analizEdiliyor
                              ? const Padding(
                                  padding: EdgeInsets.all(20),
                                  child: CircularProgressIndicator(
                                    color: Colors.green, strokeWidth: 3,
                                  ),
                                )
                              : const Icon(
                                  Icons.camera_alt,
                                  size: 32, color: Colors.black,
                                ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
