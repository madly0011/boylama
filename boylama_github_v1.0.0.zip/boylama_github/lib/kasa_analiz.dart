// Version: 1.0.0
// Kasa Analiz Motoru — Dart implementasyonu
// OpenCV olmadan: köşe tespiti + Hough dairesi + KNN sınıflandırma

import 'dart:math';
import 'dart:typed_data';
import 'package:image/image.dart' as img;

// ─────────────────────────────────────────────────────────
// VERİ YAPILARI
// ─────────────────────────────────────────────────────────

class Meyve {
  final int x, y, r;
  const Meyve(this.x, this.y, this.r);
}

class AnalizSonucu {
  final int toplamMeyve;
  final List<int> siraPattern;
  final int siraSayisi;
  final bool offsetVar;
  final int? kasaBoyutu;
  final double guven;
  final bool bilinmiyor;
  final String mod; // "KNN" veya "TFLite"

  const AnalizSonucu({
    required this.toplamMeyve,
    required this.siraPattern,
    required this.siraSayisi,
    required this.offsetVar,
    this.kasaBoyutu,
    required this.guven,
    this.bilinmiyor = false,
    this.mod = 'KNN',
  });

  String get patternStr => siraPattern.join('+');
  String get kasaStr => kasaBoyutu != null ? "$kasaBoyutu'lik" : "?";
  String get guvenStr => '%${(guven * 100).toStringAsFixed(0)}';
}

// ─────────────────────────────────────────────────────────
// KASA ŞEMALARI
// ─────────────────────────────────────────────────────────

const Map<int, List<int>> kasaSchemalar = {
  12: [4, 4, 4],
  14: [5, 4, 5],
  16: [4, 4, 4, 4],
  18: [5, 4, 5, 4],
  20: [5, 5, 5, 5],
  22: [6, 5, 6, 5],
  24: [6, 6, 6, 6],
  26: [7, 6, 7, 6],
  28: [7, 7, 7, 7],
};

// ─────────────────────────────────────────────────────────
// BÖLÜM 1 — GÖRÜNTÜ İŞLEME (Dart/image paketi)
// ─────────────────────────────────────────────────────────

class GoruntуIsleme {

  /// Görüntüyü gri tonlamaya çevir
  static List<List<int>> griDonustur(img.Image image) {
    final gri = List.generate(
      image.height,
      (y) => List.generate(image.width, (x) {
        final p = image.getPixel(x, y);
        return ((p.r * 0.299) + (p.g * 0.587) + (p.b * 0.114)).toInt();
      }),
    );
    return gri;
  }

  /// Gaussian blur
  static List<List<int>> gaussianBlur(List<List<int>> gri, int kernel) {
    final h = gri.length, w = gri[0].length;
    final sonuc = List.generate(h, (y) => List.filled(w, 0));
    final yari = kernel ~/ 2;

    for (int y = yari; y < h - yari; y++) {
      for (int x = yari; x < w - yari; x++) {
        int toplam = 0, sayac = 0;
        for (int ky = -yari; ky <= yari; ky++) {
          for (int kx = -yari; kx <= yari; kx++) {
            toplam += gri[y + ky][x + kx];
            sayac++;
          }
        }
        sonuc[y][x] = toplam ~/ sayac;
      }
    }
    return sonuc;
  }

  /// Canny kenar tespiti (basitleştirilmiş Sobel)
  static List<List<int>> cannyKenar(List<List<int>> gri) {
    final h = gri.length, w = gri[0].length;
    final kenar = List.generate(h, (y) => List.filled(w, 0));

    for (int y = 1; y < h - 1; y++) {
      for (int x = 1; x < w - 1; x++) {
        final gx = -gri[y-1][x-1] + gri[y-1][x+1]
                 - 2*gri[y][x-1]   + 2*gri[y][x+1]
                 - gri[y+1][x-1]   + gri[y+1][x+1];
        final gy = -gri[y-1][x-1] - 2*gri[y-1][x] - gri[y-1][x+1]
                 + gri[y+1][x-1]   + 2*gri[y+1][x] + gri[y+1][x+1];
        final mag = sqrt(gx*gx + gy*gy).toInt();
        kenar[y][x] = mag > 50 ? 255 : 0;
      }
    }
    return kenar;
  }

  /// Perspektif düzeltme — en büyük dörtgeni bul
  /// Basitleştirilmiş: görüntü sınırlarını kullanır +
  /// kontur taraması ile kasa dikdörtgenini tahmin eder
  static img.Image perspektifDuzelt(img.Image image) {
    // Şimdilik görüntüyü normalize et (boyutlandır)
    // Gerçek perspektif: homografi için 4 köşe tespiti gerekir
    // Bu basit versiyon görüntüyü merkezler ve oranı düzeltir
    final h = image.height, w = image.width;

    // En büyük kare bölgeyi al (kasa genellikle dikdörtgen)
    if (w > h * 1.5) {
      // Çok geniş — yatay kırp
      final yeniW = (h * 1.4).toInt();
      final baslangic = (w - yeniW) ~/ 2;
      return img.copyCrop(image, x: baslangic, y: 0, width: yeniW, height: h);
    } else if (h > w * 1.5) {
      // Çok uzun — dikey kırp
      final yeniH = (w * 1.4).toInt();
      final baslangic = (h - yeniH) ~/ 2;
      return img.copyCrop(image, x: 0, y: baslangic, width: w, height: yeniH);
    }
    return image;
  }
}

// ─────────────────────────────────────────────────────────
// BÖLÜM 2 — MEYVELERİ TESPİT ET
// ─────────────────────────────────────────────────────────

class MeyveTespitci {

  /// Görüntüden meyveleri tespit et
  /// Hough Circle yerine: parlaklık merkezi + blob analizi
  static List<Meyve> tespit(img.Image image) {
    final h = image.height, w = image.width;
    final minR = (min(h, w) * 0.05).toInt();
    final maxR = (min(h, w) * 0.15).toInt();

    // Görüntüyü gri yap ve yumuşat
    final gri = GoruntуIsleme.griDonustur(image);
    final blur = GoruntуIsleme.gaussianBlur(gri, 9);

    // Lokal maksimum nokta tespiti (meyve merkezi)
    final meyveler = <Meyve>[];
    final pencere = maxR;

    for (int y = pencere; y < h - pencere; y += minR) {
      for (int x = pencere; x < w - pencere; x += minR) {
        // Bu noktadaki parlaklık lokal maksimum mu?
        final merkez = blur[y][x];
        if (merkez < 80) continue; // Çok karanlık

        // Çevre ile karşılaştır
        bool lokalMaks = true;
        for (int dy = -pencere ~/ 2; dy <= pencere ~/ 2; dy += 3) {
          for (int dx = -pencere ~/ 2; dx <= pencere ~/ 2; dx += 3) {
            if (dy == 0 && dx == 0) continue;
            final ny = y + dy, nx = x + dx;
            if (ny >= 0 && ny < h && nx >= 0 && nx < w) {
              if (blur[ny][nx] > merkez + 5) {
                lokalMaks = false;
                break;
              }
            }
          }
          if (!lokalMaks) break;
        }

        if (lokalMaks) {
          // Renk kontrolü: turuncu-kırmızı meyve rengi mi?
          final p = image.getPixel(x, y);
          final r = p.r.toInt(), g = p.g.toInt(), b = p.b.toInt();
          // Şeftali rengi: r yüksek, g orta, b düşük
          if (r > 120 && r > g + 20 && r > b + 30) {
            meyveler.add(Meyve(x, y, (minR + maxR) ~/ 2));
          }
        }
      }
    }

    // Çakışanları temizle
    return _cakisanlariTemizle(meyveler);
  }

  /// Çakışan tespitleri kaldır
  static List<Meyve> _cakisanlariTemizle(List<Meyve> meyveler) {
    final sirali = List<Meyve>.from(meyveler)
      ..sort((a, b) => a.y != b.y ? a.y.compareTo(b.y) : a.x.compareTo(b.x));

    final temiz = <Meyve>[];
    for (final m in sirali) {
      bool cakisiyor = false;
      for (final t in temiz) {
        final mesafe = sqrt(pow(m.x - t.x, 2) + pow(m.y - t.y, 2));
        if (mesafe < (m.r + t.r) * 0.6) {
          cakisiyor = true;
          break;
        }
      }
      if (!cakisiyor) temiz.add(m);
    }
    return temiz;
  }
}

// ─────────────────────────────────────────────────────────
// BÖLÜM 3 — SIRALARA GRUPLA
// ─────────────────────────────────────────────────────────

List<List<Meyve>> siralraGrupla(List<Meyve> meyveler) {
  if (meyveler.isEmpty) return [];

  final ortR = meyveler.map((m) => m.r).reduce((a, b) => a + b) / meyveler.length;
  final tolerans = ortR * 1.4;

  final sirali = List<Meyve>.from(meyveler)..sort((a, b) => a.y.compareTo(b.y));
  final siralar = <List<Meyve>>[];
  var guncel = [sirali[0]];
  var guncelY = sirali[0].y.toDouble();

  for (int i = 1; i < sirali.length; i++) {
    final m = sirali[i];
    if ((m.y - guncelY).abs() <= tolerans) {
      guncel.add(m);
    } else {
      guncel.sort((a, b) => a.x.compareTo(b.x));
      siralar.add(List.from(guncel));
      guncel = [m];
      guncelY = m.y.toDouble();
    }
  }
  if (guncel.isNotEmpty) {
    guncel.sort((a, b) => a.x.compareTo(b.x));
    siralar.add(guncel);
  }

  // Makul sıra sayısı: 2-6
  return siralar;
}

// ─────────────────────────────────────────────────────────
// BÖLÜM 4 — FEATURE VEKTÖRÜ
// ─────────────────────────────────────────────────────────

List<double> featureVektorOlustur(
  List<Meyve> meyveler,
  List<List<Meyve>> siralar,
  bool offset,
  int imgH,
  int imgW,
) {
  if (meyveler.isEmpty) return List.filled(16, 0.0);

  final toplam = meyveler.length;
  final siraSayisi = siralar.length;
  final pattern = siralar.map((s) => s.length).toList();
  final ortR = meyveler.map((m) => m.r).reduce((a,b)=>a+b) / meyveler.length;

  final xs = meyveler.map((m) => m.x.toDouble()).toList();
  final ys = meyveler.map((m) => m.y.toDouble()).toList();
  final xYayilim = (xs.reduce(max) - xs.reduce(min)) / imgW;
  final yYayilim = (ys.reduce(max) - ys.reduce(min)) / imgH;

  final tek  = pattern.asMap().entries.where((e)=>e.key%2==0).map((e)=>e.value.toDouble());
  final cift = pattern.asMap().entries.where((e)=>e.key%2==1).map((e)=>e.value.toDouble());
  final ortTek  = tek.isNotEmpty  ? tek.reduce((a,b)=>a+b)/tek.length  : 0.0;
  final ortCift = cift.isNotEmpty ? cift.reduce((a,b)=>a+b)/cift.length : 0.0;

  final maxCols = pattern.reduce(max);
  final minCols = pattern.reduce(min);

  final meyveAlani = meyveler.fold(0.0, (s, m) => s + pi * m.r * m.r);
  final kasaAlani  = xYayilim * imgW * yYayilim * imgH;
  final doluluk    = kasaAlani > 0 ? (meyveAlani / kasaAlani).clamp(0.0, 1.0) : 0.0;

  double duzenlilik = 1.0;
  if (siraSayisi > 1) {
    final siraYler = siralar.map((s) => s.map((m)=>m.y.toDouble()).reduce((a,b)=>a+b)/s.length).toList();
    final dy = List.generate(siraYler.length-1, (i)=>siraYler[i+1]-siraYler[i]);
    final ortDy = dy.reduce((a,b)=>a+b)/dy.length;
    final stdDy = sqrt(dy.map((d)=>pow(d-ortDy,2)).reduce((a,b)=>a+b)/dy.length);
    duzenlilik = (1 - stdDy/(ortDy+1e-6)).clamp(0.0, 1.0);
  }

  final ortaX = imgW / 2;
  final sol = meyveler.where((m)=>m.x < ortaX).length;
  final simetri = 1 - (sol - (toplam - sol)).abs() / toplam;

  final stdPattern = () {
    final ort = pattern.reduce((a,b)=>a+b)/pattern.length;
    return sqrt(pattern.map((p)=>pow(p-ort,2)).reduce((a,b)=>a+b)/pattern.length);
  }();

  return [
    toplam / 30.0,
    siraSayisi / 5.0,
    siraSayisi > 0 ? (toplam / siraSayisi) / 8.0 : 0.0,
    minCols > 0 ? maxCols / minCols.toDouble() : 1.0,
    offset ? 1.0 : 0.0,
    ortR / min(imgH, imgW),
    meyveAlani / (imgH * imgW),
    duzenlilik,
    xYayilim,
    yYayilim,
    ortTek / 8.0,
    ortCift / 8.0,
    stdPattern / 3.0,
    maxCols / 8.0,
    doluluk,
    simetri,
  ];
}

// ─────────────────────────────────────────────────────────
// BÖLÜM 5 — KNN SINIFLANDIRICI
// ─────────────────────────────────────────────────────────

class KNNSiniflandirici {
  final List<List<double>> _X = [];
  final List<int> _y = [];
  static const int k = 7;
  static const double guvenEsigi = 0.75;

  void egit(Map<int, List<int>> schemalar, List<Map<String,dynamic>> gercekOrnekler) {
    _X.clear();
    _y.clear();
    final rng = Random(42);

    for (final kasa in schemalar.entries) {
      final kasaNo = kasa.key;
      final sema   = kasa.value;
      final sr     = sema.length;
      final mc     = sema.reduce(max);
      final mn     = sema.reduce(min);
      final tek    = sema.asMap().entries.where((e)=>e.key%2==0).map((e)=>e.value.toDouble());
      final cift   = sema.asMap().entries.where((e)=>e.key%2==1).map((e)=>e.value.toDouble());
      final ortTek  = tek.isNotEmpty  ? tek.reduce((a,b)=>a+b)/tek.length  : 0.0;
      final ortCift = cift.isNotEmpty ? cift.reduce((a,b)=>a+b)/cift.length : ortTek;
      final stdSema = () {
        final ort = sema.reduce((a,b)=>a+b)/sema.length;
        return sqrt(sema.map((p)=>pow(p-ort,2)).reduce((a,b)=>a+b)/sema.length);
      }();

      for (int i = 0; i < 200; i++) {
        double g([double s = 0.03]) => (rng.nextDouble() - 0.5) * 2 * s;
        final v = [
          (kasaNo + rng.nextInt(3) - 1) / 30.0,
          (sr + g(0.05)) / 5.0,
          (kasaNo / sr + g(0.1)) / 8.0,
          mn > 0 ? mc / mn + g(0.05) : 1.0,
          1.0,
          0.08 + g(0.01),
          0.45 + g(0.05),
          0.90 + g(0.05),
          0.80 + g(0.05),
          0.70 + g(0.05),
          (ortTek  + g(0.1)) / 8.0,
          (ortCift + g(0.1)) / 8.0,
          (stdSema + g(0.05)) / 3.0,
          (mc + g(0.1)) / 8.0,
          0.70 + g(0.05),
          0.85 + g(0.05),
        ].map((v) => v.clamp(0.0, 2.0)).toList();
        _X.add(v);
        _y.add(kasaNo);
      }
    }

    // Gerçek örnekleri ağırlıklı ekle
    for (final ornek in gercekOrnekler) {
      final kn = ornek['kasa_no'] as int;
      final fv = List<double>.from(ornek['feature_vektor']);
      final rng2 = Random(kn);
      for (int i = 0; i < 50; i++) {
        _X.add(fv.map((v) => (v + (rng2.nextDouble()-0.5)*0.03).clamp(0.0,2.0)).toList());
        _y.add(kn);
      }
    }
  }

  (int, double) tahminEt(List<double> fv) {
    if (_X.isEmpty) return (20, 0.0);

    // Mesafeleri hesapla
    final mesafeler = List.generate(_X.length, (i) {
      double toplam = 0;
      for (int j = 0; j < fv.length; j++) {
        toplam += pow(fv[j] - _X[i][j], 2);
      }
      return sqrt(toplam);
    });

    // En yakın k komşu
    final sirali = List.generate(_X.length, (i) => i)
      ..sort((a, b) => mesafeler[a].compareTo(mesafeler[b]));

    final oylar = <int, double>{};
    for (int i = 0; i < min(k, sirali.length); i++) {
      final idx    = sirali[i];
      final kn     = _y[idx];
      final agirlik = 1.0 / (mesafeler[idx] + 1e-6);
      oylar[kn]    = (oylar[kn] ?? 0) + agirlik;
    }

    final enIyi  = oylar.entries.reduce((a,b) => a.value > b.value ? a : b);
    final toplam = oylar.values.reduce((a,b) => a+b);
    return (enIyi.key, enIyi.value / toplam);
  }
}

// ─────────────────────────────────────────────────────────
// BÖLÜM 6 — KURAL BAZLI YEDEK
// ─────────────────────────────────────────────────────────

(int, double) kuralEslestir(List<int> pattern, Map<int, List<int>> schemalar) {
  final toplam = pattern.reduce((a,b) => a+b);
  int? enIyi;
  double enIyiS = 0.0;

  for (final e in schemalar.entries) {
    final kn   = e.key;
    final sema = e.value;
    final sayiS = max(0.0, 1 - (toplam-kn).abs() / max(toplam, kn));
    double patS;
    if (pattern.length == sema.length) {
      patS = List.generate(pattern.length, (i) => pattern[i]==sema[i]?1:0)
               .reduce((a,b)=>a+b) / sema.length;
    } else {
      patS = max(0.0, 1 - (pattern.length - sema.length).abs() * 0.25);
    }
    final s = sayiS * 0.65 + patS * 0.35;
    if (s > enIyiS) { enIyiS = s; enIyi = kn; }
  }
  return (enIyi ?? 20, enIyiS);
}

// ─────────────────────────────────────────────────────────
// BÖLÜM 7 — ANA ANALİZ MOTORu
// ─────────────────────────────────────────────────────────

class KasaAnalizMotoru {
  final KNNSiniflandirici _knn = KNNSiniflandirici();
  Map<int, List<int>> _schemalar = Map.from(kasaSchemalar);
  List<Map<String,dynamic>> _gercekOrnekler = [];
  static const double guvenEsigi = 0.75;

  void baslat(Map<String,dynamic> veri) {
    // JSON'dan şemaları yükle
    if (veri.containsKey('schemalar')) {
      _schemalar = (veri['schemalar'] as Map).map(
        (k,v) => MapEntry(int.parse(k.toString()), List<int>.from(v)),
      );
    }
    if (veri.containsKey('egitim_ornekleri')) {
      _gercekOrnekler = List<Map<String,dynamic>>.from(veri['egitim_ornekleri']);
    }
    _knn.egit(_schemalar, _gercekOrnekler);
  }

  AnalizSonucu analiz(img.Image image) {
    // 1. Perspektif düzelt
    final duzeltilmis = GoruntуIsleme.perspektifDuzelt(image);

    // 2. Meyveleri tespit et
    final meyveler = MeyveTespitci.tespit(duzeltilmis);
    if (meyveler.isEmpty) {
      return const AnalizSonucu(
        toplamMeyve: 0, siraPattern: [], siraSayisi: 0,
        offsetVar: false, guven: 0, bilinmiyor: true,
      );
    }

    // 3. Sıralara grupla
    final siralar = siralraGrupla(meyveler);
    final pattern = siralar.map((s) => s.length).toList();
    final offset  = _offsetKontrol(siralar);

    // 4. Feature vektörü
    final fv = featureVektorOlustur(
      meyveler, siralar, offset,
      duzeltilmis.height, duzeltilmis.width,
    );

    // 5. KNN tahmini
    final (knnKasa, knnGuven) = _knn.tahminEt(fv);

    // 6. Kural bazlı
    final (kuralKasa, kuralG) = kuralEslestir(pattern, _schemalar);

    // 7. Birleşik karar
    int? final0;
    double finalGuven;

    if (knnKasa == kuralKasa) {
      final0 = knnKasa; finalGuven = knnGuven;
    } else if (knnGuven >= 0.90) {
      final0 = knnKasa; finalGuven = knnGuven;
    } else if (kuralG >= 0.80) {
      final0 = kuralKasa; finalGuven = kuralG;
    } else if (knnGuven >= guvenEsigi) {
      final0 = knnKasa; finalGuven = knnGuven;
    } else {
      final0 = null; finalGuven = knnGuven;
    }

    return AnalizSonucu(
      toplamMeyve: meyveler.length,
      siraPattern: pattern,
      siraSayisi: siralar.length,
      offsetVar: offset,
      kasaBoyutu: final0,
      guven: finalGuven,
      bilinmiyor: final0 == null,
    );
  }

  bool _offsetKontrol(List<List<Meyve>> siralar) {
    if (siralar.length < 2) return false;
    final farklar = <double>[];
    for (int i = 0; i < min(siralar.length-1, 3); i++) {
      if (siralar[i].isNotEmpty && siralar[i+1].isNotEmpty) {
        farklar.add((siralar[i+1][0].x - siralar[i][0].x).toDouble());
      }
    }
    if (farklar.isEmpty) return false;
    return farklar.where((f) => f > 10).length >= farklar.length ~/ 2;
  }

  void yeniKasaOgren(int kasaNo, List<int> pattern, List<double> fv) {
    _schemalar[kasaNo] = pattern;
    _gercekOrnekler.add({
      'kasa_no': kasaNo,
      'pattern': pattern,
      'feature_vektor': fv,
      'kaynak': 'kullanici',
    });
    _knn.egit(_schemalar, _gercekOrnekler);
  }
}
